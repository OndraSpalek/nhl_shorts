import json,tempfile,unittest
from pathlib import Path
from sys import path
path.insert(0,str(Path(__file__).resolve().parents[1]))
from v66_pipeline import execute
from v67_verify import verify
ROOT=Path(__file__).resolve().parents[1]
class TestV67(unittest.TestCase):
    def test_fixture_no_render_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            execute('2026-11-22',d,fixture_path=ROOT/'demo/offline_api_fixture.json')
            self.assertEqual(verify(d)['status'],'FAIL')
    def test_fixture_cannot_pass_as_live(self):
        with tempfile.TemporaryDirectory() as d:
            execute('2026-11-22',d,fixture_path=ROOT/'demo/offline_api_fixture.json')
            self.assertTrue(any('Požadována živá data' in issue for issue in verify(d,True)['issues']))
    def test_empty_day_passes_without_video(self):
        with tempfile.TemporaryDirectory() as d:
            f=json.loads((ROOT/'demo/offline_api_fixture.json').read_text())
            f['schedule']['gameWeek'][0]['games']=[]
            fixture=Path(d)/'empty.json';fixture.write_text(json.dumps(f))
            execute('2026-11-22',Path(d)/'out',fixture_path=fixture,render=True)
            self.assertEqual(verify(Path(d)/'out')['status'],'PASS')
    def test_fixture_render_and_media(self):
        with tempfile.TemporaryDirectory() as d:
            execute('2026-11-22',d,fixture_path=ROOT/'demo/offline_api_fixture.json',render=True,allow_demo_logos=True,seconds=1)
            self.assertEqual(verify(d)['status'],'PASS')
if __name__=='__main__':unittest.main()
