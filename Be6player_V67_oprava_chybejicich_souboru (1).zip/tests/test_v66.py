import json, unittest, tempfile
from pathlib import Path
from sys import path
path.insert(0,str(Path(__file__).resolve().parents[1]))
from v66_pipeline import execute,validate
from shorts_data import build
from shorts_rank import rank

ROOT=Path(__file__).resolve().parents[1]
FIXTURE=ROOT/'demo/offline_api_fixture.json'
class TestV66(unittest.TestCase):
    def test_fixture_game_and_timezone(self):
        d=build('2026-11-22',fixture=json.loads(FIXTURE.read_text()))
        self.assertEqual(d['game_count'],1)
        self.assertEqual(d['games'][0]['home']['abbrev'],'CAR')
        self.assertTrue(validate(d))
    def test_no_invented_form(self):
        d=build('2026-11-22',fixture=json.loads(FIXTURE.read_text()))
        self.assertEqual(d['games'][0]['home']['form_all']['sample_size'],0)
        self.assertEqual(rank(d)['game_of_day_id'],100)
    def test_audit_and_explicit_fixture(self):
        with tempfile.TemporaryDirectory() as t:
            a=execute('2026-11-22',t,fixture_path=FIXTURE)
            self.assertEqual(a['mode'],'OFFLINE_FIXTURE_NOT_LIVE')
            self.assertFalse(a['voice'])
            self.assertFalse(a['youtube_upload'])
            self.assertTrue((Path(t)/'ranked.json').exists())
    def test_no_games_is_not_fabricated(self):
        with tempfile.TemporaryDirectory() as t:
            fixture=json.loads(FIXTURE.read_text())
            fixture['schedule']['gameWeek'][0]['games']=[]
            f=Path(t)/'fixture.json';f.write_text(json.dumps(fixture))
            a=execute('2026-11-22',Path(t)/'out',fixture_path=f,render=True)
            self.assertEqual(a['game_count'],0)
            self.assertTrue((Path(t)/'out/NO_GAMES.txt').exists())
    def test_duplicate_game_rejected(self):
        d=build('2026-11-22',fixture=json.loads(FIXTURE.read_text()))
        d['games'].append(d['games'][0])
        with self.assertRaises(ValueError):validate(d)
if __name__=='__main__':unittest.main()
